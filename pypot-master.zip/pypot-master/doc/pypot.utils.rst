:mod:`utils` Package
====================

.. automodule:: pypot.utils
    :members:
    :undoc-members:
    :show-inheritance:


:mod:`stoppablethread` Module
-----------------------------

.. automodule:: pypot.utils.stoppablethread
    :members:
    :undoc-members:
    :show-inheritance:
    
:mod:`trajectory` Module
-----------------------------

.. automodule:: pypot.utils.trajectory
    :members:
    :undoc-members:
    :show-inheritance:
