:mod:`sensor` Package
=====================

.. automodule:: pypot.sensor
    :members:
    :undoc-members:
    :show-inheritance:


:mod:`kinect` Module
--------------------

.. automodule:: pypot.sensor.kinect.sensor
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`optitrack` Module
-----------------------

.. automodule:: pypot.sensor.optitrack
    :members:
    :undoc-members:
    :show-inheritance:
